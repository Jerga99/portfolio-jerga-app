<div className="portfolio-detail">
  <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
  <main role="main" class="inner page-cover">
    <h1 class="cover-heading">Title</h1>
    <p class="lead dates">dates</p>
    <p class="lead info mb-0">jobTitle | company | location</p>
    <p class="lead">description</p>
    <p class="lead">
      <a href="#" class="btn btn-lg btn-secondary">Visit Company</a>
    </p>
  </main>
  </div>
</div>
